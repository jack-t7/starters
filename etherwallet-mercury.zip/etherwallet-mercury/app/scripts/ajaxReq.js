'use strict';
var ajaxReq = function() {}
ajaxReq.http = null;
ajaxReq.postSerializer = null;
ajaxReq.getETHvalue = null;
ajaxReq.getRates = null;
module.exports = ajaxReq;
